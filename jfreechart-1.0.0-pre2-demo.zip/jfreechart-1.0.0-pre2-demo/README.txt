*******************************************
* JFREECHART DEMO COLLECTION (1.0.0-pre2) *
*******************************************

9 March 2005

1)  OVERVIEW
------------
This collection of JFreeChart demo applications includes:

    - all the source code for the demo application that is included in the
      JFreeChart distribution;
    - the source code for the JDBC and servlet demos described in the
      JFreeChart Developer Guide.
    - a few additional demos that you might also find helpful.

To run the main demo type:

    java -jar jfreechart-1.0.0-pre2-demo.jar

This collection is only available for download to purchasers of the JFreeChart
Developer Guide.  Thanks for supporting the JFreeChart project.
